.. _spi_controller:

SPI Controller
###############

Overview
********

A simple sample that sends incrementing byte to SPI peripheral.
