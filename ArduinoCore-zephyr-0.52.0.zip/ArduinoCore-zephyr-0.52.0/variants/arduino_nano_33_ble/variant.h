/*
 * Copyright (c) 2022 Dhruva Gole
 *
 * SPDX-License-Identifier: Apache-2.0
 */

// TODO: correctly handle these legacy defines
#define MOSI    11
#define MISO    12
#define SCK     13
#define SS      10
#define SDA     0
#define SCL     0