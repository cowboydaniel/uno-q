/*
 * Copyright (c) 2024 Ayush Singh <ayush@beagleboard.org>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once

#define PIN_WIRE_SCL D12
#define PIN_WIRE_SDA D11
