---
name: Compilation bug report
about: Sketch doesn't compile
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Target board + cli verbose compilation output**
**Full verbose** compilation output, ideally with `arduino-cli` invocation or from IDE 2.3.3+
Issues without the full verbose output will be discarded as invalid.

**Mandatory: attach the sketch**
or a Minimal reproducible example
Issues without the sketch will be discarded as invalid.

**Additional context**
Add any other context about the problem here.
