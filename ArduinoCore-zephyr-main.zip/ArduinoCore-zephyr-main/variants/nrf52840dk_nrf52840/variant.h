/*
 * Copyright (c) 2022 Mike Szczys
 *
 * SPDX-License-Identifier: Apache-2.0
 */
