// placeholder to allow the discovery of this library
